emailjs.init("JIv_9Sc5JsO6E9cUl")  // public key

emailjs.sendForm(
  'YOUR_SERVICE_ID',      // 'service_gmailRose'
  'YOUR_TEMPLATE_ID',     // 'template_bookingRose'
  form
)
